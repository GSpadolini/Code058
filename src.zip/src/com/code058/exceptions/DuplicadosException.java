package com.code058.exceptions;

public class DuplicadosException extends Exception{
    public DuplicadosException(String mensaje){
        super(mensaje);
    }
}

