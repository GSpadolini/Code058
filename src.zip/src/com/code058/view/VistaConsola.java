package com.code058.view;

import com.code058.model.Articulo;
import com.code058.model.Cliente;
import com.code058.model.Pedido;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class VistaConsola {
    private Scanner scanner;

    public VistaConsola() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarMenuPrincipal() {
        System.out.println("\n==================================");
        System.out.println("||        MENU PRINCIPAL        ||");
        System.out.println("==================================");
        System.out.println("1. Gestion de Articulos");
        System.out.println("2. Gestion de Clientes");
        System.out.println("3. Gestion de Pedidos");
        System.out.println("0. Salir de la aplicacion");
        System.out.println("==================================");
    }

    public int pedirOpcion() {
        int opcion = -1;
        System.out.println("Selecciona una opcion: ");

        try {
            opcion = scanner.nextInt();
            scanner.nextLine();
        } catch (java.util.InputMismatchException e) {
            scanner.nextLine();
            mostrarError("Entrada no válida. Por favor, introduce un número.");
            opcion = -1;
        }
        return opcion;
    }

    public void mostrarMensaje(String mensaje){
        System.out.println(mensaje);
    }

    public void mostrarError(String error) {
        System.err.println("!!! ERROR: " + error);
    }

    public String pedirString(){
        return scanner.nextLine();
    }

    public double pedirDouble(){
        double numeroDecimal = 0.0;
        boolean valido = false;

        do {
            String numeroString = scanner.nextLine();
            try {
                numeroDecimal = Double.parseDouble(numeroString);
                valido = true;
            } catch (NumberFormatException e) {
                mostrarError("Formato incorrecto. Por favor, introduce un número decimal");
            }
        } while (!valido);

        return numeroDecimal;
    }

    public int pedirInt(){
        int numeroNoDecimal = 0;
        boolean valido = false;
        do {
            String numeroString = scanner.nextLine();
            try {
                numeroNoDecimal = Integer.parseInt(numeroString);
                valido = true;
            } catch (NumberFormatException e) {
                mostrarError("Formato incorrecto. Por favor, introduce un número entero");
            }
        } while (!valido);
        return numeroNoDecimal;
    }

    public void mostrarMenuArticulos(){
        System.out.println("Menu Gestion de Articulo");
        System.out.println("Elige una opcion");
        System.out.println("1. Añadir Articulo");
        System.out.println("2. Mostrat Articulo");
        System.out.println("0. Ir al menu principal");
    }

    // ----------------------------
    // NUEVO: imprimir por LIST (recomendado)
    // ----------------------------
    public void imprimirListaArticulos(List<Articulo> articulos) {
        if (articulos == null || articulos.isEmpty()) {
            System.out.println("No hay artículos.");
            return;
        }
        System.out.println("=== LISTA ARTÍCULOS ===");
        for (Articulo a : articulos) {
            System.out.println(a); // usa toString de Articulo
        }
    }

    public void imprimirListaClientes(List<Cliente> clientes){
        if (clientes == null || clientes.isEmpty()) {
            System.out.println("No hay clientes.");
            return;
        }
        System.out.println("=== LISTA CLIENTES ===");
        for (Cliente c : clientes) {
            System.out.println(c); // usa toString de Cliente / subclases
        }
    }

    // ----------------------------
    // MANTENER compatibilidad: imprimir por MAP (antigua)
    // ----------------------------
    public void imprimirListaArticulos(Map<String, Articulo> articulos) {
        if (articulos == null || articulos.isEmpty()) {
            System.out.println("No hay artículos (map).");
            return;
        }
        System.out.println("=== MAP ARTÍCULOS ===");
        articulos.forEach((codigo, articulo) ->
                System.out.println("Codigo del Articulo: " + codigo + ", " + articulo)
        );
    }

    public void imprimirListaClientes(Map<String, Cliente> clientes){
        if (clientes == null || clientes.isEmpty()) {
            System.out.println("No hay clientes (map).");
            return;
        }
        System.out.println("=== MAP CLIENTES ===");
        clientes.forEach((email,cliente) ->
                System.out.println("Email " + email + ", " + cliente));
    }

    public void imprimirListaClientesFiltrados(List<Cliente> lista){
        if(lista == null || lista.isEmpty()){
            System.out.println("No hay clientes en esta categoría");
        } else {
            lista.forEach(c -> System.out.println(c.toString()));
        }
    }

    public void mostrarMenuCliente(){
        System.out.println("Menu Gestion de Cliente");
        System.out.println("Elige una opcion");
        System.out.println("1. Añadir Cliente");
        System.out.println("2. Mostrar Clientes");
        System.out.println("3. Mostrar Cliente Estandar");
        System.out.println("4. Mostrar Cliente Primium");
        System.out.println("0. Ir al menu principal");
    }

    public void mostrarMenuPedidos(){
        System.out.println("Menu Gestion de Pedidos");
        System.out.println("Elige una opcion");
        System.out.println("1. Crear Pedido");
        System.out.println("2. Eliminar Pedido");
        System.out.println("3. Mostrar Todos los Pedidos Pendientes");
        System.out.println("4. Mostrar los Pedidos Pendientes filtrados por Cliente");
        System.out.println("5. Mostrar Pedidos Completados");
        System.out.println("6. Mostrar Pedidos Completados filtrados por Cliente");
        System.out.println("0. Ir al menu principal");
    }

    public void imprimirListaPedidos(List<Pedido> pedidos) {
        if (pedidos == null || pedidos.isEmpty()) {
            System.out.println("No hay pedidos para mostrar.");
            return;
        }

        System.out.println("=== LISTA DE PEDIDOS ===");
        for (Pedido p : pedidos) {
            System.out.println("Número: " + p.getNumeroPedido() +
                    " | Cliente: " + p.getCliente().getEmail() +
                    " | Artículo: " + p.getArticulo().getCodigo() +
                    " | Cantidad: " + p.getCantidad() +
                    " | Fecha: " + p.getFechaPedido() +
                    " | Tiempo preparación: " + p.getTiempoPreparacion() + " min" +
                    " | Total: " + p.getPrecioTotal());
        }
    }
}
